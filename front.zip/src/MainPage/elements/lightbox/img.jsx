export { default as IMG01} from '../../../assets/img/img-01.jpg';
export { default as IMG02} from '../../../assets/img/img-02.jpg';
export { default as IMG03} from '../../../assets/img/img-03.jpg';
export { default as IMG04} from '../../../assets/img/img-04.jpg';
export { default as IMG05} from '../../../assets/img/img-05.jpg';