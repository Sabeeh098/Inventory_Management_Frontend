/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */
var lightbox=GLightbox({selector:".image-popup",title:!1}),lightboxDesc=GLightbox({selector:".image-popup-desc"}),lightboxvideo=GLightbox({selector:".image-popup-video-map",title:!1});