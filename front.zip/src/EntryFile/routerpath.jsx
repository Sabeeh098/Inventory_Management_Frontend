const publicPath = '/Inventory/';

export const routeCodes = {
  HOME: publicPath,
  LOGIN: `${ publicPath }signin`,
  REGISTER: `${ publicPath }signup`,
};